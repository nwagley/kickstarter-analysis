# Kickstarting with Excel
Using Excel to find out to new analysis which will be outcomes based on goals and outcomes based on launched date. 

## Overview of Project
Analysis of Louise's play " Fever " and giving her the results of how different campaigns fared in realtion to their launch dates and their funding goals. 
### Purpose
The purpose of the this Analysis is to use the kickstarter dataset that was given and modified by us inorder to to visualize campaign outcomes based on their launch dates and their funding goals. 

## Analysis and Challenges

I used the data and modified it based on the categories such as campaign goals , money that was pledged and outcomes that were successful vs which were not successful. I also looked at the Percentage of the Funding donation and category to see if there is any corelation. Looking at the Outcomes and filtering it by parent category we could see how much each of the categories were successful based on the country. For example we could see that in GB ( Great Britian ) only theater has a stronger outcome vs in the US ( united states ) where there was a strong outcome on music and theater. I also looked at indivisual palys to see if the donations were successful or not and weather it met lousises goal. 

### Analysis of Outcomes Based on Launch Date
To Analyze the data outcomes based on lauch date I used excel to vizualize the campaign outcomes for example. I looked at the if the campaign was successful, did it fail ? and how many times it was canceled. Then I used this data and catogorised it between each month of the year and using any filters to find out Parent Category or Subcategory. 

### Analysis of Outcomes Based on Goals
To Analyze the outcomes based on goals I used excel to vizualize the percentage of how successful the campaign was and also looked at the percentage of failure and cancelations. I corelated this based on the funding amount or the Goal louise had. I then used the data from the subcategory section and filtered it to only show plays so that an exact percentage could be seen. 

### Challenges and Difficulties Encountered

The chanlleges I came across this project was when I had to corelate the data based on dates and year to see when exactly we could see the outcomes that was successful or not. I overcame this challenge by using formulas to calculate the dates see if they matched the goals and if the launched date and deadline made sense when we were understating on how much money was raised on a particular month or year. By Sub Catogorizing the theater and plays it beacome more clear on what the desired outcomes were needed.  

## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date?

Looking at this analysis we can see that the months February and March have the best numbers for sucessess in terms of numbers and only looking at theater. 
We can also see that every 6 months there is a reccuring theme of cancelations which is a negetive for lousie 

- What can you conclude about the Outcomes based on Goals?

Looking at this analysis we can see that as when there is a increase or surplus of money involved or the target is higher the success rate becomes low and the chances of faiure is high. 

- What are some limitations of this dataset?
The limitations of the dataset can be on the numbers provided and if it was used at the desired outcome i,e catogories and sub catogories in this case. 

- What are some other possible tables and/or graphs that we could create?
We could use the bar graph to see the success and failure rate of each month based on outcomes. We can also use a box plot to see if there is a outlier on the data we have. 
